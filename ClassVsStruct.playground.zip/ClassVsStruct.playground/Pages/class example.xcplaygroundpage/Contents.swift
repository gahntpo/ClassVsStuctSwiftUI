//: [Previous](@previous)

import Foundation



var item1 = ItemClass(name: "first") {
    willSet {
      print("willSet:  \(newValue)")
    }
}

let item2 = item1 // passing a reference

item1.name = "changed"

print(item1.name)
print(item2.name)




//: [Next](@next)
