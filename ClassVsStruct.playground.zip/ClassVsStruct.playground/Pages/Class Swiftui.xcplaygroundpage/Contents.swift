//: [Previous](@previous)

import PlaygroundSupport
import SwiftUI

// not update correctly with class model

var item = ItemClass(name: "first")
let view = ContentView(item: item)

PlaygroundPage.current.setLiveView(view)
//: [Next](@next)
