//: [Previous](@previous)

import Foundation
import Darwin


var item1 = ItemStruct(name: "first") {
    willSet {
      print("willSet:  \(newValue)")
    }
}

let item2 = item1 // create copy

item1.name = "changed"

print(item1.name)
print(item2.name)





//: [Next](@next)
