
import PlaygroundSupport
import SwiftUI

// working update correctly with model struct

var item = ItemStruct(name: "first")
let view = ContentView(item: item)

PlaygroundPage.current.setLiveView(view)
