//: [Previous](@previous)



import PlaygroundSupport
import SwiftUI
import CoreData

// working update correctly with model struct

class ContentViewModel: ObservableObject {
    
    @Published var item = ItemClass(name: "first")
}


struct ContentView: View {
    
    // Core data
//    @FetchRequest(sortDescriptors: []) var students: FetchedResults<ItemClass>
//     realm database
//    @ObservedResults(Item.self) var items
    
    @StateObject var viewModel = ContentViewModel()
    
    var body: some View {
        VStack {
            Text("Item Struct")
                .font(.title)
            
            Text("name: \(viewModel.item.name)")
                .font(.headline)
            Text("number: \(viewModel.item.number)")
                .font(.headline)
            
            TextField("name", text: $viewModel.item.name)
                .textFieldStyle(.roundedBorder)
            
            Button {
                viewModel.item.number += 1
            } label: {
                Text("increase number")
            }
            
            Button {
                viewModel.objectWillChange.send()
            } label: {
                Text("refresh UI")
            }


        }
        .frame(width: 400, height: 600)
    }
}

PlaygroundPage.current.setLiveView(ContentView())

//: [Next](@next)
