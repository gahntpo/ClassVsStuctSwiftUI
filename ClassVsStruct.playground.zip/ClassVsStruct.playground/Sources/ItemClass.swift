import Foundation

public class ItemClass: ItemProtocol, Identifiable {
    
    public var name: String
    public let id: UUID
    public var number: Int
    
    public init(name: String) {
        self.id = UUID()
        self.number = 0
        self.name = name
    }
}
