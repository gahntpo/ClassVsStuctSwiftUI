import Foundation

public protocol ItemProtocol {
    
    var name: String { get set }
    var number: Int { get set }
    
    mutating func increase()
}

extension ItemProtocol {
   public mutating func increase() {
        self.number += 1
    }
}
