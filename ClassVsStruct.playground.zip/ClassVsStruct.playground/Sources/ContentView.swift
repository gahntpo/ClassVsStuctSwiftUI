import SwiftUI

public struct ContentView<T>: View where T: ItemProtocol {
    
    @State private var item: T
    
    public init(item:  T) {
        self._item = State(initialValue: item)
    }
    
    public var body: some View {
        VStack {
            Text("Item Struct")
                .font(.title)
           
            
            Text("name: \(item.name)")
                .font(.headline)
            Text("number: \(item.number)")
                .font(.headline)
            
            TextField("name", text: $item.name)
                .textFieldStyle(.roundedBorder)
            
            Button {
                item.increase()
            } label: {
                Text("increase number")
            }

        }
        .frame(width: 400, height: 600)
    }
}
