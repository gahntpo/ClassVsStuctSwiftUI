import Foundation

public struct ItemStruct: ItemProtocol {
    
    public var name: String
    let id: UUID
    public var number: Int = 0
    
    public init(name: String) {
        self.name = name
        self.id = UUID()
    }
}
